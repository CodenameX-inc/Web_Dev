Used SQLite database for storing data
no need for custom initialization, the codes to initialize the database
and the table is made in the code, but in case of any error of the database
not being found, then just create ${courses.sqlite} file in the ${courses} folder