"""mkctf custom exceptions
"""


class MKCTFAPIException(Exception):
    """mkctf API exception"""
