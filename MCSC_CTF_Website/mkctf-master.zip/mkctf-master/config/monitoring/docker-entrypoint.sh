#!/bin/sh
mkctf-monitor --timeout 600 --delay 600
