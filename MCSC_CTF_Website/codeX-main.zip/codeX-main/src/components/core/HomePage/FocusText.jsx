import React from "react";
import "./focus.css";

const FocusText = (props) => {
  return <charge>{props.text}</charge>;
};

export default FocusText;
