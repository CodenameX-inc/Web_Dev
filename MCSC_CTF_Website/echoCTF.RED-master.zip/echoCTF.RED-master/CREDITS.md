# Credits
We would like to thank the following people for their contributions, support and persistence :)
* @HitmanAlharbi for numerous contributions, bug reports and support
* @harperaa for suggestions on, and testing of our documentation
* @Pegasus0xx for reporting XSS in the backend operations
* @bibaf for support and bug reports to the frontend and backend operations

Original project could not have been made possible without the help and contributions of the following
* @gadamo, @pkotsiop, @akorovesi
