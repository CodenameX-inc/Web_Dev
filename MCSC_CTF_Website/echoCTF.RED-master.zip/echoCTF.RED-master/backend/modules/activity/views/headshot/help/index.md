List of players and targets they have completed:

Fields include:
* `Player`: The player who this headshot belongs to
* `Target`: The target that was completed
* `Timer`: The time it took from first contact to completion
* `First`: Flag denoting that this headshot was the first on the target
* `Rating`: The user difficulty rating for this target
* `Created at`: When the completion took place