Players who have managed to succesfuly solve a challenge are kept here along with their details such as:

* Player ID and Username
* Challenge ID and Name
* Timer in seconds that took to complete the challenge
* Rating of the player for the challenge
* First solver or not
