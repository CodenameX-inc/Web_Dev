Inquiries received from the frontend for various purposes.

The table also holds the serialized model that produced this communication so that we can distinguish the different types of inquiries that can be received.

Fileds include:
* `Player`: The player id associated with this inquiry
* `Name`: The name of the user provided on the forms
* `Email`: The email address we need to contact
* `Anwered`: Flag of wether or not we've answered this inquiry
* `Category`: A free-form category for the inquiry
* `Serialized`: The serialized object that produced this entry
* `Body`: The message from the user