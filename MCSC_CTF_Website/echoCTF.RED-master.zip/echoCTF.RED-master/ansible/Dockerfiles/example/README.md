# Target: {target_name}
a general description of the target

## Learning objectives
what will the players learn by completing this target?

## Target goals
Any special goals for the target.

## Target Administration
Target administrative and other management details.

## Refs
References for the target material

## Exploitation
Step by step exploitation and getting all the flags.
