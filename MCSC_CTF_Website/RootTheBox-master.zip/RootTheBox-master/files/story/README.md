Story Avatars
=============
Admin provided Story Images can be placed in this directory and referenced by "/story/imagefile.jpg".
