Game Materials
=============
Location for you to drop game materials that the player can use in the game - such as documents, files, applications, forensic images, etc.  Can include folder structure.
If a folder is named after a box and use_box_materials_dir is True, the files within will be noted in the box page.
