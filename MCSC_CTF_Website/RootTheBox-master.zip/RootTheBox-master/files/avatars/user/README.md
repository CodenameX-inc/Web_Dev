User Avatars
=============
Admin provided User Avatars can be placed in this directory.  w500 x h250, 'png', 'jpeg', 'gif', 'bmp', 'svg'
