Avatar Uploads
=============
User based avatar uploads are placed in this directory by RTB.