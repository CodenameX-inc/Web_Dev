$(document).ready(function() {
    $("#pass1").popover({placement:'right', trigger:'focus'});
    $("#pass2").popover({placement:'right', trigger:'focus'});
});