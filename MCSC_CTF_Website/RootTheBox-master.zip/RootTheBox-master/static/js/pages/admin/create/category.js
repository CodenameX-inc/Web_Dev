$(document).ready(function() {

    /* Enable popovers */
    $("#category").popover({placement: 'right', trigger: 'hover'});
});
