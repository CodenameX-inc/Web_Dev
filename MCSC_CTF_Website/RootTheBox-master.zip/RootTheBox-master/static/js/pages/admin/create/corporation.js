$(document).ready(function() {

    /* Enable popovers */
    $("#corporation-name").popover({placement: 'right', trigger: 'hover'});
});
